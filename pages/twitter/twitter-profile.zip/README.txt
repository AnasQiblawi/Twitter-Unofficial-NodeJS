A Pen created at CodePen.io. You can find this one at https://codepen.io/BeanBaag/pen/rrdPYE.

 This is a little Twitter profile badge that was designed by Kenneth Patterson. Find the design on Dribbble here https://dribbble.com/shots/2872995-Day-57-Twitter-Profile.

This was made during by stream on Twitch, you can watch the whole development here https://www.twitch.tv/beanbaag/v/94104216/.

Find me on social media:

https://www.twitch.tv/beanbaag

https://twitter.com/BeanBaag