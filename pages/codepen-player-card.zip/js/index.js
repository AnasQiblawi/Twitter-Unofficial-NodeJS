/* 

    Nothing strengthens authority so much as silence.
    
    - Leonardo da Vinci

*/