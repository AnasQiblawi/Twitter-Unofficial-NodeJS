A Pen created at CodePen.io. You can find this one at https://codepen.io/BeanBaag/pen/yJxpLE.

 Trying something out that I think would be a nice addition to CodePen. The whole thought of a player card is like a trading card. Granted it is just the style now but if you wanted to take it to your site and have a section for people please be my guest.

Tweet at me your creation, @BeanBaag, I would love to see.

If there is anything I have missed or can be improved please let me know or fork it and see what you can expand on. Would love to see what you come up with.